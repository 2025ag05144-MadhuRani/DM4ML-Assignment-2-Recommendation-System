
import os
import pandas as pd
from datetime import datetime

PROJECT_PATH = os.path.dirname(
    os.path.dirname(os.path.abspath(__file__))
)

STAGES = [
    ("Data Ingestion", "data/raw",
     ["users.csv", "items.csv", "interactions.csv"]),

    ("Data Validation", "reports",
     ["data_validation_report.csv"]),

    ("Data Preparation", "data/processed",
     ["users_clean.csv", "items_clean.csv",
      "interactions_clean.csv", "train_data.csv", "test_data.csv"]),

    ("Feature Engineering", "data/features",
     ["user_features.csv", "item_features.csv",
      "interaction_features.csv"]),

    ("Model Training", "models",
     ["popularity_model.csv", "item_similarity_matrix.csv",
      "personalized_recommendations_user1.csv"]),

    ("Model Evaluation", "reports",
     ["model_evaluation_results.csv", "precision_recall.png",
      "ndcg_comparison.png", "coverage_diversity.png"])
]

results = []

print("STARTING RECOMMENDATION PIPELINE")

for stage, folder, files in STAGES:

    missing = [
        f for f in files
        if not os.path.isfile(
            os.path.join(PROJECT_PATH, folder, f)
        )
    ]

    status = "SUCCESS" if not missing else "FAILED"

    print(stage, ":", status)

    results.append({
        "Stage": stage,
        "Status": status,
        "Missing Files": ", ".join(missing),
        "Execution Time": datetime.now().isoformat()
    })

os.makedirs(os.path.join(PROJECT_PATH, "reports"), exist_ok=True)

pd.DataFrame(results).to_csv(
    os.path.join(
        PROJECT_PATH,
        "reports",
        "workflow_execution_log.csv"
    ),
    index=False
)

print("WORKFLOW CHECK COMPLETED")
